#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
data = root / "js/data.js"
ui = root / "js/ui.js"
css = root / "styles.css"

replacements = {
'  SOL: { symbol: "SOL", name: "Solana", cg: "solana", hue: 265, home: "solana" },':
'  SOL: { symbol: "SOL", name: "Solana", cg: "solana", hue: 265, home: "solana", image: "https://assets.coingecko.com/coins/images/4128/large/solana.png" },',
'  ETH: { symbol: "ETH", name: "Ether", cg: "ethereum", hue: 225, home: "ethereum" },':
'  ETH: { symbol: "ETH", name: "Ether", cg: "ethereum", hue: 225, home: "ethereum", image: "https://assets.coingecko.com/coins/images/279/large/ethereum.png" },',
'  BNB: { symbol: "BNB", name: "BNB", cg: "binancecoin", hue: 42, home: "bnb" },':
'  BNB: { symbol: "BNB", name: "BNB", cg: "binancecoin", hue: 42, home: "bnb", image: "https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png" },',
'  POL: { symbol: "POL", name: "Polygon", cg: "polygon-ecosystem-token", hue: 275, home: "polygon" },':
'  POL: { symbol: "POL", name: "Polygon", cg: "polygon-ecosystem-token", hue: 275, home: "polygon", image: "https://assets.coingecko.com/coins/images/4713/large/polygon-token.png" },',
'  AVAX: { symbol: "AVAX", name: "Avalanche", cg: "avalanche-2", hue: 355, home: "avalanche" },':
'  AVAX: { symbol: "AVAX", name: "Avalanche", cg: "avalanche-2", hue: 355, home: "avalanche", image: "https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Transparent.png" },',
'  SUI: { symbol: "SUI", name: "Sui", cg: "sui", hue: 195, home: "sui" },':
'  SUI: { symbol: "SUI", name: "Sui", cg: "sui", hue: 195, home: "sui", image: "https://assets.coingecko.com/coins/images/26375/large/sui_asset.jpg" },',
'  ARB: { symbol: "ARB", name: "Arbitrum", cg: "arbitrum", hue: 205, home: "arbitrum" },':
'  ARB: { symbol: "ARB", name: "Arbitrum", cg: "arbitrum", hue: 205, home: "arbitrum", image: "https://assets.coingecko.com/coins/images/16547/large/Arbitrum.png" },',
'  JUP: { symbol: "JUP", name: "Jupiter", cg: "jupiter-exchange-solana", hue: 150, home: "solana" },':
'  JUP: { symbol: "JUP", name: "Jupiter", cg: "jupiter-exchange-solana", hue: 150, home: "solana", image: "https://assets.coingecko.com/coins/images/34188/large/jup.png" },',
'  BONK: { symbol: "BONK", name: "Bonk", cg: "bonk", hue: 24, home: "solana" },':
'  BONK: { symbol: "BONK", name: "Bonk", cg: "bonk", hue: 24, home: "solana", image: "https://assets.coingecko.com/coins/images/28600/large/bonk.jpg" },',
'  WBTC: { symbol: "WBTC", name: "Wrapped Bitcoin", cg: "wrapped-bitcoin", hue: 28, home: "ethereum" },':
'  WBTC: { symbol: "WBTC", name: "Wrapped Bitcoin", cg: "wrapped-bitcoin", hue: 28, home: "ethereum", image: "https://assets.coingecko.com/coins/images/7598/large/wrapped_bitcoin_wbtc.png" },',
'  USDC: { symbol: "USDC", name: "USD Coin", cg: "usd-coin", hue: 212, stable: true, home: "ethereum" },':
'  USDC: { symbol: "USDC", name: "USD Coin", cg: "usd-coin", hue: 212, stable: true, home: "ethereum", image: "https://assets.coingecko.com/coins/images/6319/large/USD_Coin_icon.png" },',
'  USDT: { symbol: "USDT", name: "Tether", cg: "tether", hue: 165, stable: true, home: "ethereum" },':
'  USDT: { symbol: "USDT", name: "Tether", cg: "tether", hue: 165, stable: true, home: "ethereum", image: "https://assets.coingecko.com/coins/images/325/large/Tether.png" },'
}
s = data.read_text()
for old, new in replacements.items():
    if old not in s:
        raise SystemExit("Token definition not found: " + old)
    s = s.replace(old, new)
data.write_text(s)

u = ui.read_text()
old = '''export function tokenAvatar(token, size = "") {
  const long = token.symbol.length > 3 ? " long" : "";
  return `<span class="tok ${size}${long}" style="--h:${token.hue}" aria-hidden="true">${esc(token.symbol.slice(0, 4))}</span>`;
}'''
new = '''export function tokenAvatar(token, size = "") {
  const long = token.symbol.length > 3 ? " long" : "";
  const fallback = esc(token.symbol.slice(0, 4));
  if (token.image) {
    return `<span class="tok ${size}${long} tok-image" style="--h:${token.hue}" aria-hidden="true"><img src="${esc(token.image)}" alt="" loading="lazy" decoding="async" onerror="this.parentElement.classList.add('tok-image-failed');this.remove()"><span>${fallback}</span></span>`;
  }
  return `<span class="tok ${size}${long}" style="--h:${token.hue}" aria-hidden="true">${fallback}</span>`;
}'''
if old not in u:
    raise SystemExit("tokenAvatar function not found")
ui.write_text(u.replace(old, new))

marker = '.tok-xl.long { font-size: .75rem; }'
extra = '''
.tok-image { position: relative; background: var(--surface); }
.tok-image img { width: 100%; height: 100%; display: block; object-fit: cover; border-radius: 50%; }
.tok-image > span { position: absolute; inset: 0; display: none; place-items: center; }
.tok-image-failed > span { display: grid; }
'''
c = css.read_text()
if '.tok-image {' not in c:
    if marker not in c:
        raise SystemExit("token CSS marker not found")
    css.write_text(c.replace(marker, marker + extra))
print("NXT CLOUD token logo patch applied")
